
NOVALEI PATCH — Search & Crossword (v2025-10-02)

Purpose
- Provide build() entrypoints matching the Hub contract.
- Enforce: WS tier=T3 default, words_per_puzzle=30 default, ≥2 clusters; CW has no tier.
- Do NOT re-cluster. Engines must use provided clusters.
- Write normalized request copy (req_norm.json) and validate required fields before delegating.

Install
1) Search: copy `search/build.py` into your generator folder:
   <your-project>/api/generators/search/build.py

2) Crossword: copy `crossword/build.py` into your generator folder:
   <your-project>/api/generators/crossword/build.py

3) Your existing engine code should expose one of:
   - search:  search_gen.build_internal(request_dict, out_dir)
              or generator.build_wordsearch(request_dict, out_dir)
   - crossword: crossword_gen.build_internal(request_dict, out_dir)
                or generator.build_crossword(request_dict, out_dir)

Behavior
- The shim reads request.json (or dict), validates and normalizes per spec, saves req_norm.json,
  then tries to call the internal engine. If no engine is found, it writes generator.log with guidance
  and returns. Hub will read the outputs (puzzle.svg etc.) when engine writes them.

Files created by shim
- req_norm.json  : normalized request
- generator.log  : messages from the shim or engine errors

Expected engine outputs (same folder)
- Word Search: puzzle.svg, answers.svg, layout.json
- Crossword:   puzzle.svg, answers.svg, clues.json, layout.json
