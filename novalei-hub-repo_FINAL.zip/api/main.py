"""
FastAPI application for the Novalei puzzle hub.

This module exposes a small REST API which covers the main flows outlined in
the Novalei hub specification.  It handles ingestion of a WordBank ZIP
containing CSV exports, generates draft puzzles for word search and
crossword types using the simple engines provided in ``api/generators``,
allows those puzzles to be approved or rejected, and serves the resulting
assets for preview in the web UI.  A minimal HTML front‑end lives in
``web/index.html`` and interacts with these endpoints via fetch calls.

The focus of this implementation is to provide a working demonstration
without recreating the full sophistication of the production Novalei
pipeline.  The puzzle generators emit placeholder SVGs rather than fully
fledged puzzles and the KDP PDF builder is intentionally omitted.  You can
extend these components as needed.
"""
from __future__ import annotations

import csv
import datetime
import io
import json
import os
import random
import sqlite3
import string
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .clusterer.utils import segment_graphemes

# Constants for database and output locations.  The database file lives
# alongside this module under ``db/novalei.sqlite``.  Puzzle assets are
# stored under ``out/<puzzle_id>/``.  These directories are created at
# startup if they do not already exist.
BASE_DIR = Path(__file__).resolve().parent
DB_DIR = BASE_DIR / "db"
DB_PATH = DB_DIR / "novalei.sqlite"
OUT_DIR = BASE_DIR / "out"

# Create FastAPI instance.
app = FastAPI(title="Novalei Puzzle Hub", version="0.1")


def get_db() -> sqlite3.Connection:
    """Open a connection to the SQLite database with row factory set."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    """Initialise the database schema if it does not already exist."""
    DB_DIR.mkdir(parents=True, exist_ok=True)
    conn = get_db()
    cur = conn.cursor()
    # Create tables for themes, words, word_theme mappings and puzzles.
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS themes (
            id    INTEGER PRIMARY KEY AUTOINCREMENT,
            name  TEXT UNIQUE
        );
        """
    )
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS words (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            gu            TEXT,
            en            TEXT,
            clusters      TEXT,
            cluster_count INTEGER
        );
        """
    )
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS word_themes (
            word_id  INTEGER,
            theme_id INTEGER
        );
        """
    )
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS puzzles (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            type       TEXT,
            theme_id   INTEGER,
            created_at TEXT,
            status     TEXT,
            words      TEXT,
            metadata   TEXT,
            out_dir    TEXT,
            fingerprint TEXT
        );
        """
    )
    conn.commit()
    conn.close()


@app.on_event("startup")
def on_startup() -> None:
    """Initialise database and ensure output directory exists on startup."""
    init_db()
    OUT_DIR.mkdir(parents=True, exist_ok=True)


# Ensure the output directory exists at import time so StaticFiles does not
# raise an exception.  Starlette requires the directory to exist when
# mounting.
OUT_DIR.mkdir(parents=True, exist_ok=True)

# Mount the puzzle asset directory as a static file mount point.  Puzzle
# assets live in ``OUT_DIR`` and can be served under ``/static``.  This
# allows the front‑end to preview puzzle SVGs and other files without
# implementing additional endpoints.
if not hasattr(app, "static_mounted"):
    app.mount("/static", StaticFiles(directory=str(OUT_DIR), html=False), name="static")
    app.static_mounted = True  # type: ignore[attr-defined]


class BuildPuzzleRequest(BaseModel):
    """
    Pydantic model for the puzzle build request.

    ``type`` must be either ``wordsearch`` or ``crossword``.  ``theme``
    references the name of a theme imported via the WordBank.  ``count``
    specifies how many draft puzzles to create (default: 1).  Additional
    fields can be added in the future to customise puzzle size or other
    options.
    """

    type: str = Field(..., description="Puzzle type: 'wordsearch' or 'crossword'")
    theme: str = Field(..., description="Name of the theme for which to build puzzles")
    count: int = Field(1, description="Number of puzzles to build", ge=1, le=20)


@app.post("/wordbank/ingest-zip")
async def ingest_wordbank(request: Request) -> Dict[str, Any]:
    """
    Ingest a WordBank ZIP file containing three CSV exports and populate the
    database.

    The expected archive must contain ``words_export.csv``,
    ``themes_export.csv`` and ``word_themes_export.csv``.  All existing
    data in the database is removed before the new data is inserted.  Words
    that contain hyphens in either the Gurmukhi or English text are
    excluded.  Cluster information is taken from the CSV if present; if
    clusters are missing the clusterer is used to segment the Gurmukhi
    string.

    Returns a JSON object listing the number of themes and words imported.
    """
    # Read the uploaded file into memory.  The client should send the raw zip
    # bytes in the request body with content type ``application/octet-stream``.
    data = await request.body()
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except Exception:
        raise HTTPException(status_code=400, detail="Provided file is not a valid ZIP archive")

    required = {"words_export.csv", "themes_export.csv", "word_themes_export.csv"}
    names = set(zf.namelist())
    if not required.issubset(names):
        raise HTTPException(status_code=400, detail="ZIP archive must contain words_export.csv, themes_export.csv and word_themes_export.csv")

    # Parse the CSVs into memory.
    def read_csv(name: str) -> List[Dict[str, str]]:
        with zf.open(name) as fh:
            text = io.TextIOWrapper(fh, encoding="utf-8")
            reader = csv.DictReader(text)
            return [dict(row) for row in reader]

    words_rows = read_csv("words_export.csv")
    themes_rows = read_csv("themes_export.csv")
    mapping_rows = read_csv("word_themes_export.csv")

    # Clear existing data.
    conn = get_db()
    cur = conn.cursor()
    cur.execute("DELETE FROM word_themes")
    cur.execute("DELETE FROM words")
    cur.execute("DELETE FROM themes")
    conn.commit()

    # Insert themes.
    theme_id_map: Dict[str, int] = {}
    for row in themes_rows:
        name = row.get("name") or row.get("theme") or row.get("title") or row.get("display_name")
        if not name:
            continue
        name = name.strip()
        cur.execute("INSERT OR IGNORE INTO themes(name) VALUES(?)", (name,))
    conn.commit()
    # Build a mapping from CSV id to DB id.
    cur.execute("SELECT id, name FROM themes")
    for tid, name in cur.fetchall():
        theme_id_map[str(tid)] = tid
        # also map by name for convenience
        theme_id_map[name] = tid

    # Insert words.
    word_id_map: Dict[str, int] = {}
    for row in words_rows:
        csv_id = row.get("id") or row.get("word_id") or row.get("ID")
        gu = (row.get("gu") or row.get("word_gu") or row.get("word")).strip() if (row.get("gu") or row.get("word_gu") or row.get("word")) else None
        en = (row.get("en") or row.get("translation") or row.get("clue")).strip() if (row.get("en") or row.get("translation") or row.get("clue")) else None
        clusters_str = row.get("clusters") or row.get("cluster") or row.get("cluster_str")
        # Skip words with hyphens in either form.
        if gu and "-" in gu:
            continue
        if en and "-" in en:
            continue
        # Determine cluster list.
        clusters: List[str] = []
        if clusters_str:
            clusters_str = clusters_str.strip()
            # Attempt to parse JSON or Python list literal.
            try:
                clusters = json.loads(clusters_str)
            except Exception:
                try:
                    import ast
                    clusters = ast.literal_eval(clusters_str)
                except Exception:
                    # Fallback: split by spaces.
                    clusters = clusters_str.split()
        if not clusters and gu:
            clusters = segment_graphemes(gu)
        cluster_count = len(clusters)
        # Insert into words table.
        cur.execute(
            "INSERT INTO words(gu,en,clusters,cluster_count) VALUES(?,?,?,?)",
            (gu, en, json.dumps(clusters, ensure_ascii=False), cluster_count),
        )
        db_word_id = cur.lastrowid
        if csv_id:
            word_id_map[str(csv_id)] = db_word_id
    conn.commit()

    # Insert word_theme mappings.
    inserted_links = 0
    for row in mapping_rows:
        w_id = row.get("word_id") or row.get("wordID") or row.get("word")
        t_id = row.get("theme_id") or row.get("themeID") or row.get("theme")
        if not w_id or not t_id:
            continue
        word_db_id = word_id_map.get(str(w_id))
        theme_db_id = theme_id_map.get(str(t_id))
        if word_db_id and theme_db_id:
            cur.execute("INSERT INTO word_themes(word_id, theme_id) VALUES(?,?)", (word_db_id, theme_db_id))
            inserted_links += 1
    conn.commit()
    # Count imported.
    cur.execute("SELECT COUNT(*) FROM words")
    words_count = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM themes")
    themes_count = cur.fetchone()[0]
    conn.close()
    return {"status": "ok", "themes": themes_count, "words": words_count, "links": inserted_links}


@app.get("/themes")
def list_themes() -> Dict[str, Any]:
    """Return a list of all theme names currently loaded in the database."""
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT name FROM themes ORDER BY name ASC")
    names = [row[0] for row in cur.fetchall()]
    conn.close()
    return {"themes": names}


@app.get("/puzzles")
def list_puzzles(status: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    List all puzzles in the database with optional status filtering.

    :param status: Optional status filter ('draft', 'approved', 'rejected').
    :return: List of puzzle metadata dictionaries.
    """
    conn = get_db()
    cur = conn.cursor()
    sql = "SELECT p.id, p.type, p.created_at, p.status, t.name AS theme_name, p.out_dir FROM puzzles p JOIN themes t ON p.theme_id = t.id"
    params: List[Any] = []
    if status:
        sql += " WHERE p.status = ?"
        params.append(status)
    sql += " ORDER BY p.id DESC"
    cur.execute(sql, params)
    rows = cur.fetchall()
    conn.close()
    result: List[Dict[str, Any]] = []
    for row in rows:
        puzzle_id = row["id"]
        preview_url = f"/static/{puzzle_id}/puzzle.svg"
        result.append({
            "id": puzzle_id,
            "type": row["type"],
            "theme": row["theme_name"],
            "created_at": row["created_at"],
            "status": row["status"],
            "preview": preview_url
        })
    return result


def _generate_wordsearch(theme_id: int, theme_name: str, count: int) -> List[int]:
    """Helper to generate one or more word search puzzles."""
    conn = get_db()
    cur = conn.cursor()
    # Fetch candidate words for the theme (must have at least two clusters).
    cur.execute(
        """
        SELECT w.id, w.gu, w.en, w.clusters, w.cluster_count
        FROM words w
        JOIN word_themes wt ON wt.word_id = w.id
        WHERE wt.theme_id = ? AND w.cluster_count >= 2
        """,
        (theme_id,)
    )
    candidates = cur.fetchall()
    if len(candidates) < 30:
        conn.close()
        raise HTTPException(status_code=400, detail=f"Not enough words with ≥2 clusters for theme '{theme_name}' (found {len(candidates)}, need at least 30)")

    # Build puzzles.
    created_ids: List[int] = []
    for _ in range(count):
        # Sample words for this puzzle.  Avoid duplicates across approved puzzles by
        # checking the fingerprint (sorted list of words).  We allow at most 10
        # attempts to find a unique set before giving up.
        attempts = 0
        selected = []
        fingerprint = None
        while attempts < 10:
            sample = random.sample(candidates, 30)
            # Compute fingerprint as a comma‑joined sorted string of gu terms.
            gu_list = [row["gu"] or row["en"] or "" for row in sample]
            fingerprint = ",".join(sorted(gu_list))
            # Check against existing approved puzzles for same theme.
            cur.execute(
                "SELECT 1 FROM puzzles WHERE theme_id = ? AND fingerprint = ? AND status = 'approved'",
                (theme_id, fingerprint),
            )
            exists = cur.fetchone()
            if not exists:
                selected = sample
                break
            attempts += 1
        if not selected:
            # Fall back to first sample even if duplicate.
            selected = random.sample(candidates, 30)
            gu_list = [row["gu"] or row["en"] or "" for row in selected]
            fingerprint = ",".join(sorted(gu_list))

        # Prepare request dict as per the specification.
        words_req: List[Dict[str, Any]] = []
        for row in selected:
            clusters = json.loads(row["clusters"])
            words_req.append({
                "gu": row["gu"],
                "en": row["en"],
                "clue": row["en"] or row["gu"],
                "clusters": clusters,
            })
        request_dict: Dict[str, Any] = {
            "type": "wordsearch",
            "theme": theme_name,
            "tier": "T3",
            "rules_version": "2025-10-02",
            "cluster_source": "db@v1",
            "seed": random.randint(1, 1_000_000),
            "words_per_puzzle": 30,
            "directions": ["N", "NE", "E", "SE", "S", "SW", "W", "NW"],
            "backwards": True,
            "words": words_req,
        }
        # Insert puzzle record with status 'draft'.  We reserve an ID so we can
        # create the output directory based on the puzzle ID.
        created_at = datetime.datetime.utcnow().isoformat()
        cur.execute(
            "INSERT INTO puzzles(type, theme_id, created_at, status, words, metadata, out_dir, fingerprint) "
            "VALUES(?,?,?,?,?,?,?,?)",
            (
                "wordsearch",
                theme_id,
                created_at,
                "draft",
                json.dumps([row["gu"] or row["en"] or "" for row in selected], ensure_ascii=False),
                None,
                None,
                fingerprint,
            ),
        )
        puzzle_id = cur.lastrowid
        out_path = OUT_DIR / str(puzzle_id)
        out_path.mkdir(parents=True, exist_ok=True)
        # Save the request.json for debugging.
        with open(out_path / "request.json", "w", encoding="utf-8") as f:
            json.dump(request_dict, f, ensure_ascii=False, indent=2)
        # Call the generator shim to produce outputs.
        try:
            from .generators.search import build as search_build
            search_build(request_dict, str(out_path))
        except Exception as exc:
            # Record the error in generator.log and mark puzzle as rejected.
            log_path = out_path / "generator.log"
            with open(log_path, "a", encoding="utf-8") as lf:
                lf.write(f"Generator error: {exc}\n")
            cur.execute(
                "UPDATE puzzles SET status = ? WHERE id = ?",
                ("rejected", puzzle_id),
            )
            conn.commit()
            continue
        # Update puzzle record with output directory.
        cur.execute(
            "UPDATE puzzles SET out_dir = ? WHERE id = ?",
            (str(out_path), puzzle_id),
        )
        conn.commit()
        created_ids.append(puzzle_id)
    conn.close()
    return created_ids


def _generate_crossword(theme_id: int, theme_name: str, count: int) -> List[int]:
    """Helper to generate one or more crossword puzzles."""
    conn = get_db()
    cur = conn.cursor()
    # Fetch candidate entries for the theme (any number of clusters acceptable).
    cur.execute(
        """
        SELECT w.id, w.gu, w.en, w.clusters
        FROM words w
        JOIN word_themes wt ON wt.word_id = w.id
        WHERE wt.theme_id = ?
        """,
        (theme_id,)
    )
    candidates = cur.fetchall()
    if len(candidates) < 10:
        conn.close()
        raise HTTPException(status_code=400, detail=f"Not enough words for crossword theme '{theme_name}' (found {len(candidates)}, need at least 10)")

    created_ids: List[int] = []
    for _ in range(count):
        # For crosswords we pick up to 50 entries.  If fewer are available we
        # take them all.
        take = min(50, len(candidates))
        sample = random.sample(candidates, take)
        # Compute fingerprint for deduplication.
        gu_list = [row["gu"] or row["en"] or "" for row in sample]
        fingerprint = ",".join(sorted(gu_list))
        # Check for existing approved puzzles.
        cur.execute(
            "SELECT 1 FROM puzzles WHERE theme_id = ? AND fingerprint = ? AND status = 'approved'",
            (theme_id, fingerprint),
        )
        exists = cur.fetchone()
        if exists:
            # Accept duplicate; we could resample but this suffices.
            pass
        # Prepare request dict.
        entries_req: List[Dict[str, Any]] = []
        for row in sample:
            clusters = json.loads(row["clusters"])
            entries_req.append({
                "gu": row["gu"],
                "clue": row["en"] or row["gu"],
                "clusters": clusters,
            })
        request_dict: Dict[str, Any] = {
            "type": "crossword",
            "theme": theme_name,
            "rules_version": "2025-10-02",
            "cluster_source": "db@v1",
            "seed": random.randint(1, 1_000_000),
            "grid": {"rows": 17, "cols": 17, "symmetry": False},
            "rules": {"non_stacking": True, "cluster_crossings_exact": True, "minis_cap": 2},
            "entries_take": take,
            "entries": entries_req,
        }
        # Insert puzzle record.
        created_at = datetime.datetime.utcnow().isoformat()
        cur.execute(
            "INSERT INTO puzzles(type, theme_id, created_at, status, words, metadata, out_dir, fingerprint) "
            "VALUES(?,?,?,?,?,?,?,?)",
            (
                "crossword",
                theme_id,
                created_at,
                "draft",
                json.dumps([row["gu"] or row["en"] or "" for row in sample], ensure_ascii=False),
                None,
                None,
                fingerprint,
            ),
        )
        puzzle_id = cur.lastrowid
        out_path = OUT_DIR / str(puzzle_id)
        out_path.mkdir(parents=True, exist_ok=True)
        with open(out_path / "request.json", "w", encoding="utf-8") as f:
            json.dump(request_dict, f, ensure_ascii=False, indent=2)
        try:
            from .generators.crossword import build as cw_build
            cw_build(request_dict, str(out_path))
        except Exception as exc:
            log_path = out_path / "generator.log"
            with open(log_path, "a", encoding="utf-8") as lf:
                lf.write(f"Generator error: {exc}\n")
            cur.execute(
                "UPDATE puzzles SET status = ? WHERE id = ?",
                ("rejected", puzzle_id),
            )
            conn.commit()
            continue
        cur.execute(
            "UPDATE puzzles SET out_dir = ? WHERE id = ?",
            (str(out_path), puzzle_id),
        )
        conn.commit()
        created_ids.append(puzzle_id)
    conn.close()
    return created_ids


@app.post("/puzzles/build")
def build_puzzles(req: BuildPuzzleRequest) -> Dict[str, Any]:
    """
    Build one or more draft puzzles of the specified type and theme.

    On success returns a list of new puzzle IDs.  Puzzle assets are
    generated immediately and stored under ``/static/<id>/`` for preview.
    """
    # Look up the theme ID.
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT id FROM themes WHERE name = ?", (req.theme,))
    row = cur.fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail=f"Theme '{req.theme}' not found")
    theme_id = row[0]
    if req.type not in {"wordsearch", "crossword"}:
        raise HTTPException(status_code=400, detail="type must be 'wordsearch' or 'crossword'")
    if req.type == "wordsearch":
        created = _generate_wordsearch(theme_id, req.theme, req.count)
    else:
        created = _generate_crossword(theme_id, req.theme, req.count)
    return {"created": created}


def _update_puzzle_status(puzzle_id: int, new_status: str) -> None:
    """Internal helper to update the status of a puzzle."""
    conn = get_db()
    cur = conn.cursor()
    # Verify puzzle exists.
    cur.execute("SELECT id FROM puzzles WHERE id = ?", (puzzle_id,))
    if not cur.fetchone():
        conn.close()
        raise HTTPException(status_code=404, detail="Puzzle not found")
    cur.execute("UPDATE puzzles SET status = ? WHERE id = ?", (new_status, puzzle_id))
    conn.commit()
    conn.close()


@app.post("/puzzles/approve")
def approve_puzzle(puzzle_id: int) -> Dict[str, Any]:
    """Mark the specified puzzle as approved."""
    _update_puzzle_status(puzzle_id, "approved")
    return {"status": "ok", "puzzle_id": puzzle_id, "new_status": "approved"}


@app.post("/puzzles/reject")
def reject_puzzle(puzzle_id: int) -> Dict[str, Any]:
    """Mark the specified puzzle as rejected."""
    _update_puzzle_status(puzzle_id, "rejected")
    return {"status": "ok", "puzzle_id": puzzle_id, "new_status": "rejected"}


@app.post("/puzzles/revoke")
def revoke_puzzle(puzzle_id: int) -> Dict[str, Any]:
    """Revoke an approved or rejected puzzle back to draft status."""
    _update_puzzle_status(puzzle_id, "draft")
    return {"status": "ok", "puzzle_id": puzzle_id, "new_status": "draft"}
