"""
Utilities for working with grapheme clusters.

The real Novalei clusterer is expected to break input text into grapheme
clusters and determine whether a given cluster is valid.  In order to keep
this scaffold self‑contained and easy to run in this challenge environment
we implement very simple versions of these functions here.

Two functions are exported:

* ``segment_graphemes(text)`` – given a Unicode string, return a list of
  “clusters”.  A cluster can consist of a base character followed by zero
  or more combining marks.  In this minimal implementation we treat each
  codepoint as its own cluster.  If your real clusterer performs more
  sophisticated segmentation you should drop it into this file.

* ``valid_cluster(cluster)`` – return True if the cluster is acceptable for
  inclusion in a puzzle.  This implementation simply checks that the
  cluster is a non‑empty string.  Replace this with your own logic if you
  wish to filter out unwanted clusters.

These functions are used by the WordBank ingestion code when counting the
number of clusters per word.
"""
from typing import List

def segment_graphemes(text: str) -> List[str]:
    """
    Break a string into grapheme clusters.

    This minimal implementation simply returns a list of individual
    characters.  It will not correctly handle complex scripts or emoji but
    suffices for the purposes of this exercise.  If you have access to a
    more capable grapheme segmentation library (for example the ``regex``
    module with the ``\X`` pattern) feel free to replace this
    implementation.

    :param text: Unicode string to segment.
    :return: List of cluster strings.
    """
    if not text:
        return []
    # Return each codepoint as a separate cluster.
    return [ch for ch in text]

def valid_cluster(cluster: str) -> bool:
    """
    Decide whether a particular cluster should be considered valid.

    A real implementation might filter out punctuation, whitespace, digits or
    other undesired characters.  Here we treat any non‑empty string as
    valid.

    :param cluster: The cluster string to check.
    :return: True if the cluster may be used in a puzzle.
    """
    return bool(cluster)
