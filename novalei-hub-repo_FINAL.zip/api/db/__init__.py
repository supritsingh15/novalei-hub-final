"""Database subpackage.

Contains database initialisation and access helpers for the Novalei hub.
The SQLite database file will live under this package in the ``novalei.sqlite``
file.  See ``api/main.py`` for schema creation.
"""
