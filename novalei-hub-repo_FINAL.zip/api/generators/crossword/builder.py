import argparse, json, yaml, sys
from pathlib import Path
from selector import selector_run
from solver import solve
from verifier import verify
from renderer import render_svg
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--words", required=True); ap.add_argument("--outdir", required=True); args=ap.parse_args()
    cfg=yaml.safe_load(Path("config.yaml").read_text(encoding="utf-8")); out=Path(args.outdir); out.mkdir(parents=True, exist_ok=True)
    data=json.loads(Path(args.words).read_text(encoding="utf-8"))
    report, sel = selector_run(cfg, data["words"])
    Path(out/"precheck_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    if not report["ok"]: sys.exit(2)
    Path(out/"shortlist.json").write_text(json.dumps(sel["shortlist"], ensure_ascii=False, indent=2), encoding="utf-8")
    placement = solve(cfg, sel["shortlist"], sel["clustered_words"])
    if placement is None: sys.exit(3)
    Path(out/"placement.json").write_text(json.dumps(placement, ensure_ascii=False, indent=2), encoding="utf-8")
    proof = verify(cfg, placement); Path(out/"proof.json").write_text(json.dumps(proof, ensure_ascii=False, indent=2), encoding="utf-8")
    if not proof.get("is_valid", False): sys.exit(4)
    svg = render_svg(cfg, placement); Path(out/"grid.svg").write_text(svg, encoding="utf-8"); print("OK")
if __name__=="__main__": main()