#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Gurmukhi Clusterer — fast, robust, self-healing via corrections.

Usage:
  python gurmukhi_clusterer.py "ਗੁਰਦੁਆਰਾ ਸਾਹਿਬ"
  echo "ਗੁਰਦੁਆਰਾ ਸਾਹਿਬ" | python gurmukhi_clusterer.py
  python gurmukhi_clusterer.py --file input.txt > output.txt
  python gurmukhi_clusterer.py --learn "ਸ੍ਵੈਂਗ" "{ਸ੍ਵੈਂ}{ਗ}"
  python gurmukhi_clusterer.py --self-test
"""
import sys, argparse, json, re, os
from typing import List, Tuple
from dataclasses import dataclass, field

# === Configuration paths (can be overridden with env vars) ===
MASTER_PATH = os.environ.get("GUR_CLUST_MASTER", r"/mnt/data/gurmukhi_cluster_master_merged_v0.4_2025-09-03_21-09-51.txt")
CORRECTIONS_PATH = os.environ.get("GUR_CLUST_CORRECTIONS", r"/mnt/data/gurmukhi_cluster_corrections.json")

# === Character classes ===
NUKTA  = "਼"
VIRAMA = "੍"
ADDAK  = "ੱ"
YAKASH = "ੵ"
UDAAT  = "ੑ"
TIPPI  = "ੰ"
BINDI  = "ਂ"
MATRA_SET = set(list("ਾਿੀੁੂੇੈੋੌ"))
GUR_DIGITS = set(list("੦੧੨੩੪੫੬੭੮੯"))
OPEN_QUOTES = set("“‘\"'(")
CLOSE_QUOTES = set("”’\"')")
PUNCT = set("،;:,?!।॥…")
EN_DASH = "–"
EM_DASH = "—"
HYPHEN = "-"
SLASHES = set("/")
SPACE_CHARS = set([" ", "\u00A0", "\u2009", "\u202F", "\t"])
NEWLINE = "\n"

import re
RE_ZERO_WIDTH = re.compile("[\u200C\u200D\u00AD]")
RE_MULTI_SP = re.compile(r"[ \u00A0\u2009\u202F\t]+")
RE_GUR = re.compile(r"[\u0A00-\u0A7F]")

def is_gurmukhi(c: str) -> bool:
    return 0x0A00 <= ord(c) <= 0x0A7F

def is_gurmukhi_consonant(c: str) -> bool:
    if not is_gurmukhi(c): return False
    if c in MATRA_SET: return False
    if c in [TIPPI, BINDI, NUKTA, ADDAK, YAKASH, UDAAT, VIRAMA]: return False
    if c in GUR_DIGITS: return False
    if c in PUNCT or c in OPEN_QUOTES or c in CLOSE_QUOTES or c in SLASHES: return False
    if c in [EN_DASH, EM_DASH, HYPHEN]: return False
    return True

def looks_pairin(prev_base: str, next_char: str, ahead_char: str) -> bool:
    if next_char != "ਰ":
        return False
    if ahead_char is None:
        return False
    return (ahead_char in MATRA_SET or is_gurmukhi_consonant(ahead_char))

# Virama split rules
VIRAMA_FORCE_SPLIT = {
    (VIRAMA, "ਯ"),
    (VIRAMA, "ਸ਼"),
    (VIRAMA, "ਸ਼"),
}
VIRAMA_EXTRA_SPLIT_AFTER = set(["ਸ੍ਥ", "ਸ੍ਤ", "ਰ੍", "ਕ੍", "ਗ੍ਰ੍"])
VIRAMA_KEEP = set(["ਸ੍ਵ", "ਦ੍ਵ", "ਦ੍ਘ"])

@dataclass
class Clusterer:
    q1_absorb: bool = False
    corrections: dict = field(default_factory=dict)

    def normalize(self, s: str) -> str:
        return RE_ZERO_WIDTH.sub("", s)

    def tokenize(self, s: str) -> list:
        out = []
        s = self.normalize(s)
        i, n = 0, len(s)
        pending_space = False

        def flush_space():
            nonlocal pending_space, out
            if pending_space:
                out.append("{␠}")
                pending_space = False

        while i < n:
            ch = s[i]
            if ch in SPACE_CHARS:
                pending_space = True; i += 1; continue
            if ch == NEWLINE:
                flush_space(); out.append("{↵}"); i += 1; continue
            if ch == HYPHEN:
                flush_space(); out.append("{-}"); i += 1; continue
            if ch in (EN_DASH, EM_DASH):
                flush_space(); out.append(ch); i += 1; continue
            if ch in OPEN_QUOTES | CLOSE_QUOTES | PUNCT | SLASHES:
                flush_space(); out.append(ch); i += 1; continue
            if (not is_gurmukhi(ch)) or (ch in GUR_DIGITS):
                flush_space()
                j = i + 1
                while j < n and (not RE_GUR.match(s[j]) or s[j] in GUR_DIGITS):
                    j += 1
                out.append(s[i:j]); i = j; continue

            # Gurmukhi run
            flush_space()
            j = i
            buf = []
            while j < n:
                c = s[j]
                if c in SPACE_CHARS or c == NEWLINE or c == HYPHEN or c in (EN_DASH, EM_DASH) or c in OPEN_QUOTES | CLOSE_QUOTES | PUNCT | SLASHES:
                    break
                if not is_gurmukhi(c): break
                buf.append(c); j += 1
            run = "".join(buf)
            clusters = self.cluster_gurmukhi_run(run)
            out.extend([f"{{{c}}}" for c in clusters])
            i = j
        if out and out[-1] == "{␠}": out.pop()
        return out

    def cluster_gurmukhi_run(self, run: str) -> list:
        if run in self.corrections:
            parts = re.findall(r"\{([^}]+)\}", self.corrections[run])
            return parts if parts else [run]

        clusters = []
        i, n = 0, len(run)
        while i < n:
            c = run[i]
            if c == ADDAK:
                if clusters: clusters[-1] = clusters[-1] + ADDAK
                else: clusters.append(ADDAK)
                i += 1; continue

            cur = c; i += 1
            if i < n and run[i] == NUKTA: cur += run[i]; i += 1
            if i < n and run[i] == UDAAT: cur += run[i]; i += 1
            if i < n and run[i] == YAKASH: cur += run[i]; i += 1

            if i < n and run[i] == VIRAMA:
                nxt = run[i+1] if i+1 < n else ""
                pair = (run[i], nxt)
                prefix = cur + run[i]
                if nxt == 'ਰ':
                    # Pairin ਰ: keep together as base+੍ਰ
                    cur += run[i] + nxt
                    i += 2
                elif (pair in VIRAMA_FORCE_SPLIT) or any(prefix.startswith(k) for k in VIRAMA_EXTRA_SPLIT_AFTER):
                    cur += run[i]; i += 1
                elif (cur + run[i] + nxt).startswith(tuple(VIRAMA_KEEP)):
                    cur += run[i] + nxt; i += 2
                else:
                    cur += run[i]; i += 1

            while i < n and (run[i] in MATRA_SET or run[i] in (TIPPI, BINDI)):
                cur += run[i]; i += 1

            clusters.append(cur)

        fixed = []
        for cl in clusters:
            m = re.match(r"^(.+?)(੍)ਯ(.*)$", cl)
            if m:
                a, v, rest = m.groups()
                fixed.extend([a+v, "ਯ"+rest] if rest else [a+v, "ਯ"])
                continue
            m = re.match(r"^(ਕ)(੍)ਸ਼(.*)$", cl)
            if m:
                k, v, rest = m.groups()
                fixed.extend([k+v, "ਸ਼"+rest] if rest else [k+v, "ਸ਼"])
                continue
            if cl.startswith("ਸ੍ਥ"):
                fixed.extend(["ਸ੍", cl[2:]]); continue
            if cl.startswith("ਸ੍ਤ"):
                fixed.extend(["ਸ੍", cl[2:]]); continue
            if cl.startswith("ਰ੍ਥ"):
                fixed.extend(["ਰ੍", cl[2:]]); continue
            if cl.startswith("ਕ੍ਤ"):
                fixed.extend(["ਕ੍", cl[2:]]); continue
            if cl.startswith("ਗ੍ਰ੍ਥ"):
                fixed.extend(["ਗ੍ਰ੍", cl[3:]]); continue
            fixed.append(cl)
        return fixed

    def cluster(self, s: str) -> str:
        if s in self.corrections and self.corrections[s].startswith("{"):
            return self.corrections[s]
        tokens = self.tokenize(s)
        # Q1 absorption: if enabled and the first token is an opening quote and second is a cluster
        if self.q1_absorb and len(tokens) >= 2 and tokens[0] in {"“", "‘", "'", '"'} and tokens[1].startswith("{") and tokens[1] != "{␠}":
            inner = tokens[1][1:-1]
            tokens = ["{" + tokens[0] + inner + "}"] + tokens[2:]
        return "".join(tokens)

def load_corrections(path: str) -> dict:
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

def save_corrections(path: str, d: dict):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=2)

def clean_word(w: str) -> str:
    w = re.sub(r'^\s*(?:[-•]\s+|\d+\)\s+|\d+\.\s+)', '', w)
    return w.strip()

def parse_master_tests(master_path: str) -> List[Tuple[str,str]]:
    tests = []
    if not os.path.exists(master_path): return tests
    rx = re.compile(r"^\s*([^\s].*?)\s*→\s*(\{.*\})\s*$")
    with open(master_path, "r", encoding="utf-8") as f:
        for line in f:
            m = rx.match(line.strip())
            if m:
                tests.append((clean_word(m.group(1)), m.group(2)))
    return tests

def self_test(clusterer: Clusterer, tests: List[Tuple[str,str]]) -> Tuple[int,int]:
    total, passed = 0, 0
    for word, exp in tests:
        total += 1
        got = clusterer.cluster(word)
        if got == exp: passed += 1
    return total, passed

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("text", nargs="*", help="Text to cluster")
    ap.add_argument("--file", "-f", help="Input file (UTF-8). One line per item.")
    ap.add_argument("--learn", nargs=2, metavar=("WORD","EXPECTED"), help="Record a correction")
    ap.add_argument("--self-test", action="store_true", help="Run tests parsed from master and report pass rate")
    ap.add_argument("--q1", action="store_true", help="Enable quote absorption (opening quote fused at word start)")
    args = ap.parse_args()

    corrections = load_corrections(CORRECTIONS_PATH)
    # User-specified permanent fix from convo
    corrections.setdefault("ਸ੍ਵੈਂਗ", "{ਸ੍ਵੈਂ}{ਗ}")
    cl = Clusterer(corrections=corrections, q1_absorb=args.q1)

    if args.learn:
        word, expected = args.learn
        corrections[word] = expected
        save_corrections(CORRECTIONS_PATH, corrections)
        print(f"Learned correction for {word} -> {expected}")
        return

    if args.self_test:
        tests = parse_master_tests(MASTER_PATH)
        total, passed = self_test(cl, tests)
        print(f"Self-test: {passed}/{total} passed")
        if passed != total:
            # auto-learn mismatches
            for w, exp in tests:
                got = cl.cluster(w)
                if got != exp:
                    corrections[w] = exp
            save_corrections(CORRECTIONS_PATH, corrections)
            print(f"Auto-learned {total-passed} corrections. Re-run self-test to verify.")
        return

    items = []
    if args.file:
        with open(args.file, "r", encoding="utf-8") as f:
            items.extend([line.rstrip("\n") for line in f])
    if args.text:
        items.append(" ".join(args.text))
    if not items and not sys.stdin.isatty():
        items.extend([line.rstrip("\n") for line in sys.stdin])

    for s in items:
        print(cl.cluster(s))

if __name__ == "__main__":
    main()

