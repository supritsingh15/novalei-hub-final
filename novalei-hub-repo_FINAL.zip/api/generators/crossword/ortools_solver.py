
def build_puzzle(*args, **kwargs):
    try:
        from ortools.sat.python import cp_model  # noqa: F401
    except Exception as e:
        raise RuntimeError("OR-Tools not installed. Install with `pip install ortools` or use --mode pure.") from e
    raise NotImplementedError("OR-Tools CP-SAT model not bundled here. Use --mode pure or add your CP model.")
def render_svg(*args, **kwargs):
    from pure_solver import render_svg as _r
    return _r(*args, **kwargs)
