from collections import deque
def verify(config, placement):
    S=config["grid"]["side"]; min_total=config["inclusion"]["min_total"]
    g=[[None for _ in range(S)] for _ in range(S)]
    for w in placement:
        r,c,dir_=w["row"],w["col"],w["dir"]; cl=w["clusters"]
        if dir_=="across":
            if c+len(cl)>S: return {"is_valid":False,"reason":"bounds"}
            for k,ch in enumerate(cl):
                if g[r][c+k] not in (None,ch): return {"is_valid":False,"reason":"cluster_conflict"}
                g[r][c+k]=ch
        else:
            if r+len(cl)>S: return {"is_valid":False,"reason":"bounds"}
            for k,ch in enumerate(cl):
                if g[r+k][c] not in (None,ch): return {"is_valid":False,"reason":"cluster_conflict"}
                g[r+k][c]=ch
    for r in range(S):
        for c in range(S-1):
            a,b=g[r][c],g[r][c+1]
            if a and b and a!=b: return {"is_valid":False,"reason":"non_stacking"}
    for r in range(S-1):
        for c in range(S):
            a,b=g[r][c],g[r+1][c]
            if a and b and a!=b: return {"is_valid":False,"reason":"non_stacking"}
    cells=[(r,c) for r in range(S) for c in range(S) if g[r][c]]
    if not cells: return {"is_valid":False,"reason":"empty"}
    vis=set([cells[0]]); q=deque([cells[0]])
    while q:
        r,c=q.popleft()
        for dr,dc in ((1,0),(-1,0),(0,1),(0,-1)):
            nr,nc=r+dr,c+dc
            if 0<=nr<S and 0<=nc<S and g[nr][nc] and (nr,nc) not in vis:
                vis.add((nr,nc)); q.append((nr,nc))
    if len(vis)!=len(cells): return {"is_valid":False,"reason":"disconnected"}
    if len(placement)<min_total: return {"is_valid":False,"reason":"inclusion"}
    return {"is_valid":True,"component_count":1,"included":len(placement)}