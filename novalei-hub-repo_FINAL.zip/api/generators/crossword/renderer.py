def number(grid):
    S=len(grid); nums={}; n=1
    for r in range(S):
        for c in range(S):
            if not grid[r][c]: continue
            startsA=(c==0 or not grid[r][c-1]) and (c+1<S and grid[r][c+1])
            startsD=(r==0 or not grid[r-1][c]) and (r+1<S and grid[r+1][c])
            if startsA or startsD: nums[(r,c)]=n; n+=1
    return nums

from collections import deque
def _cavity_singletons(grid):
    H, W = len(grid), len(grid[0])
    occ=[(r,c) for r in range(H) for c in range(W) if grid[r][c] is not None]
    if not occ: return set()
    min_r=min(r for r,_ in occ); max_r=max(r for r,_ in occ)
    min_c=min(c for _,c in occ); max_c=max(c for _,c in occ)
    ext=set(); q=deque()
    def push(r,c):
        if r<min_r or r>max_r or c<min_c or c>max_c: return
        if (r,c) in ext: return
        if grid[r][c] is not None: return
        ext.add((r,c)); q.append((r,c))
    singleton_cavs=_cavity_singletons(grid)
    for r in range(min_r, max_r+1):
        push(r, min_c); push(r, max_c)
    for c in range(min_c, max_c+1):
        push(min_r, c); push(max_r, c)
    while q:
        r,c=q.popleft()
        for dr,dc in ((1,0),(-1,0),(0,1),(0,-1)):
            push(r+dr, c+dc)
    interior={(r,c) for r in range(min_r,max_r+1) for c in range(min_c,max_c+1)
              if grid[r][c] is None and (r,c) not in ext}
    singles=set(); seen=set()
    for s in list(interior):
        if s in seen: continue
        comp={s}; dq=deque([s]); seen.add(s)
        while dq:
            r,c=dq.popleft()
            for dr,dc in ((1,0),(-1,0),(0,1),(0,-1)):
                t=(r+dr,c+dc)
                if t in interior and t not in seen:
                    seen.add(t); comp.add(t); dq.append(t)
        if len(comp)==1: singles.add(next(iter(comp)))
    return singles

def render_svg(config, placement):
    S=config["grid"]["side"]; cell=config["render"]["cell_px"]; pad=config["render"]["padding_px"]; font=config["render"]["font_stack"]
    g=[[None for _ in range(S)] for _ in range(S)]
    for w in placement:
        r,c,dir_=w["row"],w["col"],w["dir"]; cl=w["clusters"]
        if dir_=="across":
            for k,ch in enumerate(cl): g[r][c+k]=ch
        else:
            for k,ch in enumerate(cl): g[r+k][c]=ch
    nums=number(g)
    width=pad*2+cell*S; height=pad*2+cell*S
    out=[f'<?xml version="1.0" encoding="UTF-8"?>', f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}" shape-rendering="crispEdges">', f'<rect x="0" y="0" width="{width}" height="{height}" fill="#ffffff"/>']
    gx=pad; gy=pad
    for r in range(S):
        for c in range(S):
            x=gx+c*cell; y=gy+r*cell
            if g[r][c]:
                out.append(f'<rect x="{x}" y="{y}" width="{cell}" height="{cell}" fill="#ffffff" stroke="#000" stroke-width="0.8"/>')
                if (r,c) in nums:
                    out.append(f'<text x="{x+cell*0.12}" y="{y+cell*0.10}" font-size="{int(cell*0.18)}" text-anchor="start" dominant-baseline="hanging" font-family="Times, Serif">{nums[(r,c)]}</text>')
                out.append(f'<text x="{x+cell/2}" y="{y+cell*0.59}" font-size="{int(cell*0.40)}" text-anchor="middle" dominant-baseline="middle" font-family="{font}">{g[r][c]}</text>')
    out.append('</svg>'); return "\n".join(out)