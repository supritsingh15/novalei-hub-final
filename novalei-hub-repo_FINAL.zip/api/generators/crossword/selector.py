import json, re, os
from collections import Counter

SPACE_STRIP = re.compile(r"[ \t\u200c\u200d\u0964\u0965\u0A64\u0A65\-\–—·•|]")
def norm_text(s): return SPACE_STRIP.sub("", s)

def load_clusterer():
    from engines.gurmukhi_clusterer import Clusterer
    corr = os.path.join('engines','gurmukhi_cluster_corrections.CLEANED.json')
    try:
        return Clusterer(corrections_path=corr)
    except TypeError:
        import json
        with open(corr,'r',encoding='utf-8') as f: data=json.load(f)
        return Clusterer(corrections=data)

def segment(CL, txt):
    for name in ("cluster_gurmukhi_run","segment","segment_clusters","cluster"):
        if hasattr(CL,name):
            out=getattr(CL,name)(txt)
            if isinstance(out,(list,tuple)): return [str(x) for x in out]
    return list(txt)

def build_graph(items):
    sets=[set(x["clusters"]) for x in items]
    adj=[set() for _ in items]
    for i in range(len(items)):
        for j in range(i+1,len(items)):
            if sets[i] & sets[j]:
                adj[i].add(j); adj[j].add(i)
    return adj

def two_core(items):
    adj=build_graph(items)
    n=len(items)
    alive=[True]*n
    deg=[len(adj[i]) for i in range(n)]
    changed=True
    while changed:
        changed=False
        for i in range(n):
            if alive[i] and deg[i]<=1:
                alive[i]=False; changed=True
                for j in adj[i]:
                    if alive[j]: deg[j]-=1
    kept=[items[i] for i in range(n) if alive[i]]
    if not kept: return [], 0.0
    adj2=build_graph(kept)
    avg=sum(len(x) for x in adj2)/len(adj2)
    return kept, avg

def selector_run(config, words):
    S=config["grid"]["side"]
    cap=config["capacity"]["max_cluster_load_ratio"]
    bands=config["selection"]["length_bands"]
    CL=load_clusterer()

    items=[]
    for w in words:
        t=norm_text(w["text"])
        cl=segment(CL, t)
        items.append({"text":t,"orig":w["text"],"clue":w.get("clue",""),"clusters":cl,"len":len(cl)})
    items=[x for x in items if 2<=x["len"]<=S]
    load=sum(x["len"] for x in items)/(S*S)
    if load>cap:
        return {"ok":False,"reason":"capacity_overflow","load":load}, None

    df=Counter()
    for x in items:
        for c in set(x["clusters"]): df[c]+=1
    def rare_score(x): return sum(1 for c in set(x["clusters"]) if df[c]<=1)
    items.sort(key=lambda x:(rare_score(x), -x["len"]))
    pool=items[:32]
    core, avg = two_core(pool)
    if len(core)<config["inclusion"]["target_total"]:
        remain=[x for x in items if x not in core]
        remain.sort(key=lambda x:(-len(set(x["clusters"])), -x["len"]))
        for x in remain:
            if any(set(x["clusters"]) & set(y["clusters"]) for y in core):
                core.append(x)
                if len(core)==config["inclusion"]["target_total"]: break
    shortlist=core[:config["inclusion"]["target_total"]]
    anchors=sum(1 for x in shortlist if x["len"]>=10)
    weavers=sum(1 for x in shortlist if 5<=x["len"]<10)
    if anchors<bands["anchors_min"] or weavers<bands["weavers_min"]:
        return {"ok":False,"reason":"length_band_quota","anchors":anchors,"weavers":weavers}, None
    clustered={x["text"]:x["clusters"] for x in shortlist}
    return {"ok":True,"avg_degree_est":avg,"capacity_load":load,"count":len(shortlist)}, {"shortlist":shortlist,"clustered_words":clustered}