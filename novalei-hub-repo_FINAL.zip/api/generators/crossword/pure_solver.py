
import random, unicodedata
from collections import Counter

VIRAMA = "੍"; MATRA=set("ਾਿੀੁੂੇੈੋੌ"); DIACRITICS = MATRA|{VIRAMA,"ੰ","ਂ","ੱ","਼","ੑ","ੵ"}

def cluster_word(w):
    w = unicodedata.normalize("NFC", w).replace(" ","")
    out=[]; cur=""
    for ch in w:
        is_cons = not (ch in DIACRITICS or '੦'<=ch<='੯')
        if is_cons and cur: out.append(cur); cur=ch
        else: cur+=ch
    if cur: out.append(cur)
    return out

DIRS={'A':(0,1),'D':(1,0)}
def inb(r,c,GS): return 0<=r<GS and 0<=c<GS

def can_place_strict(grid, cl, r, c, d):
    GS=len(grid); dr,dc=DIRS[d]; L=len(cl)
    rr,cc=r+dr*(L-1), c+dc*(L-1)
    if not inb(rr,cc,GS): return False
    pr,pc=r-dr,c-dc
    if inb(pr,pc,GS) and grid[pr][pc] is not None: return False
    ar,ac=r+dr*L,c+dc*L
    if inb(ar,ac,GS) and grid[ar][ac] is not None: return False
    overlaps=0; rr,cc=r,c
    for i in range(L):
        g=grid[rr][cc]
        if g is not None and g != cl[i]: return False
        if g is None:
            if d=='A':
                if (inb(rr-1,cc,GS) and grid[rr-1][cc] is not None) or (inb(rr+1,cc,GS) and grid[rr+1][cc] is not None):
                    return False
            else:
                if (inb(rr,cc-1,GS) and grid[rr][cc-1] is not None) or (inb(rr,cc+1,GS) and grid[rr][cc+1] is not None):
                    return False
        else:
            overlaps+=1
        rr+=dr; cc+=dc
    return overlaps>=1

def place(grid, cl, r, c, d):
    dr,dc=DIRS[d]; rr,cc=r,c
    for ch in cl:
        if grid[rr][cc] is None: grid[rr][cc]=ch
        rr+=dr; cc+=dc

def crop(grid):
    GS=len(grid)
    minr,maxr,minc,maxc=GS,-1,GS,-1
    for r in range(GS):
        for c in range(GS):
            if grid[r][c] is not None:
                minr=min(minr,r); maxr=max(maxr,r); minc=min(minc,c); maxc=max(maxc,c)
    if maxr==-1: return [[None]]
    return [row[minc:maxc+1] for row in grid[minr:maxr+1]]

def cavities(g):
    R=len(g); C=len(g[0]); holes=set()
    for r in range(1,R-1):
        for c in range(1,C-1):
            if g[r][c] is not None: continue
            if (g[r-1][c] is not None and g[r+1][c] is not None and
                g[r][c-1] is not None and g[r][c+1] is not None):
                holes.add((r,c))
    return holes

def number_cells(g):
    numbers={}; n=1
    R=len(g); C=len(g[0])
    for r in range(R):
        for c in range(C):
            if g[r][c] is None: continue
            startsA=(c==0 or g[r][c-1] is None) and (c+1<C and g[r][c+1] is not None)
            startsD=(r==0 or g[r-1][c] is None) and (r+1<R and g[r+1][c] is not None)
            if startsA or startsD:
                numbers[(r,c)] = n; n+=1
    return numbers

def connector_pool_from(wordset, min_len=2, max_len=4, top_k=600):
    segs=[]
    for w in wordset:
        cl=cluster_word(w)
        for L in range(min_len, max_len+1):
            for i in range(len(cl)-L+1):
                segs.append(tuple(cl[i:i+L]))
    return [list(t) for t,_ in Counter(segs).most_common(top_k)]

def build_puzzle(words, grid_size=31, target=30, strict_no_adjacency=True,
                 connector_min=2, connector_max=4, connector_top_k=600,
                 stall_limit=180, seed=7):
    random.seed(seed)
    entries=[(w,cluster_word(w)) for w in words if len(cluster_word(w))>=2]
    entries.sort(key=lambda x:-len(x[1]))
    conns=connector_pool_from(words, connector_min, connector_max, connector_top_k)
    grid=[[None]*grid_size for _ in range(grid_size)]
    placed=[]; used=set()

    w0,c0=entries[0]; r0=grid_size//2; c0s=(grid_size-len(c0))//2
    place(grid,c0,r0,c0s,'A'); placed.append(w0); used.add(w0)
    frontier={(r0,c0s+i) for i in range(len(c0))}
    stalls=0

    while len(placed)<target and stalls<stall_limit:
        improved=False; best=None; bestL=0
        for w,cl in entries:
            if w in used: continue
            L=len(cl)
            for r,c in list(frontier):
                v=grid[r][c]
                pos=-1
                for idx,ch in enumerate(cl):
                    if ch==v: pos=idx; break
                if pos==-1: continue
                cs=c-pos
                if 0<=cs and cs+L<=grid_size and can_place_strict(grid,cl,r,cs,'A'):
                    if L>bestL: best=('A',w,cl,r,cs); bestL=L
                rs=r-pos
                if 0<=rs and rs+L<=grid_size and can_place_strict(grid,cl,rs,c,'D'):
                    if L>bestL: best=('D',w,cl,rs,c); bestL=L
        if best:
            d,w,cl,r,c=best
            place(grid,cl,r,c,d); placed.append(w); used.add(w)
            dr,dc=(0,1) if d=='A' else (1,0)
            for k in range(len(cl)): frontier.add((r+k*dr, c+k*dc))
            improved=True
        else:
            found=False
            for fcl in conns:
                L=len(fcl)
                for r,c in list(frontier):
                    v=grid[r][c]; pos=-1
                    for idx,ch in enumerate(fcl):
                        if ch==v: pos=idx; break
                    if pos==-1: continue
                    cs=c-pos
                    if 0<=cs and cs+L<=grid_size and can_place_strict(grid,fcl,r,cs,'A'):
                        place(grid,fcl,r,cs,'A'); 
                        for k in range(L): frontier.add((r, cs+k))
                        found=True; break
                    rs=r-pos
                    if 0<=rs and rs+L<=grid_size and can_place_strict(grid,fcl,rs,c,'D'):
                        place(grid,fcl,rs,c,'D'); 
                        for k in range(L): frontier.add((rs+k, c))
                        found=True; break
                if found: break
            improved = found
        stalls = 0 if improved else stalls+1

    g=crop(grid)
    return g, placed


from collections import deque
def _cavity_singletons(grid):
    H, W = len(grid), len(grid[0])
    occ=[(r,c) for r in range(H) for c in range(W) if grid[r][c] is not None]
    if not occ: return set()
    min_r=min(r for r,_ in occ); max_r=max(r for r,_ in occ)
    min_c=min(c for _,c in occ); max_c=max(c for _,c in occ)
    ext=set(); q=deque()
    def push(r,c):
        if r<min_r or r>max_r or c<min_c or c>max_c: return
        if (r,c) in ext: return
        if grid[r][c] is not None: return
        ext.add((r,c)); q.append((r,c))
    singleton_cavs=_cavity_singletons(grid)
    for r in range(min_r, max_r+1):
        push(r, min_c); push(r, max_c)
    for c in range(min_c, max_c+1):
        push(min_r, c); push(max_r, c)
    while q:
        r,c=q.popleft()
        for dr,dc in ((1,0),(-1,0),(0,1),(0,-1)):
            push(r+dr, c+dc)
    interior={(r,c) for r in range(min_r,max_r+1) for c in range(min_c,max_c+1)
              if grid[r][c] is None and (r,c) not in ext}
    singles=set(); seen=set()
    for s in list(interior):
        if s in seen: continue
        comp={s}; dq=deque([s]); seen.add(s)
        while dq:
            r,c=dq.popleft()
            for dr,dc in ((1,0),(-1,0),(0,1),(0,-1)):
                t=(r+dr,c+dc)
                if t in interior and t not in seen:
                    seen.add(t); comp.add(t); dq.append(t)
        if len(comp)==1: singles.add(next(iter(comp)))
    return singles

def render_svg(grid, cell=40, pad=16, stroke_width=2, bold_numbers=True):
    R=len(grid); C=len(grid[0])
    holes=cavities(grid); nums=number_cells(grid)
    W=pad*2 + cell*C; H=pad*2 + cell*R
    out=['<?xml version="1.0" encoding="UTF-8"?>',
         f'<svg xmlns="http://www.w3.org/2000/svg" xml:space="preserve" width="{W}" height="{H}" viewBox="0 0 {W} {H}">',
         f'<rect x="0" y="0" width="{W}" height="{H}" fill="#ffffff"/>']
    gx,gy=pad,pad
    for r in range(R):
        for c in range(C):
            val=grid[r][c]; x=gx+c*cell; y=gy+r*cell
            if (r,c) in holes:
                out.append(f'<rect x="{x}" y="{y}" width="{cell}" height="{cell}" fill="#000000"/>')
            if val is None: continue
            out.append(f'<rect x="{x}" y="{y}" width="{cell}" height="{cell}" fill="#ffffff" stroke="#000000" stroke-width="{stroke_width}"/>')
            if (r,c) in nums:
                fs=int(cell*0.22); nx=x+int(cell*0.10); ny=y+int(cell*0.25)
                weight="900" if bold_numbers else "400"
                out.append(f'<text x="{nx}" y="{ny}" font-size="{fs}" font-weight="{weight}" font-family="sans-serif" fill="#000000">{nums[(r,c)]}</text>')
            fs2=int(cell*0.44); lx=x+cell//2; ly=y+int(cell*0.70)
            out.append(f'<text x="{lx}" y="{ly}" font-size="{fs2}" text-anchor="middle" font-family="sans-serif" fill="#000000">{val}</text>')
    out.append('</svg>')
    return "\n".join(out)
