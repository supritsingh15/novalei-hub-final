from ortools.sat.python import cp_model
def solve(config, shortlist, clustered_words):
    S=config["grid"]["side"]
    max_excl=config["inclusion"]["max_exclusions"]
    words=[w["text"] for w in shortlist]
    Ls=[len(clustered_words[w]) for w in words]
    alphabet=sorted({c for w in words for c in clustered_words[w]})
    gidx={g:i for i,g in enumerate(alphabet)}
    G=len(alphabet)
    m=cp_model.CpModel()
    A={}; D={}
    for i,L in enumerate(Ls):
        for r in range(S):
            for c in range(S-L+1):
                A[(i,r,c)] = m.NewBoolVar(f"A_{i}_{r}_{c}")
        for r in range(S-L+1):
            for c in range(S):
                D[(i,r,c)] = m.NewBoolVar(f"D_{i}_{r}_{c}")
    X=[m.NewBoolVar(f"X_{i}") for i in range(len(words))]
    U=[[m.NewBoolVar(f"U_{r}_{c}") for c in range(S)] for r in range(S)]
    LBL=[ [ [m.NewBoolVar(f"L_{r}_{c}_{g}") for g in range(G)] for c in range(S)] for r in range(S)]
    for r in range(S):
        for c in range(S):
            m.Add(sum(LBL[r][c])<=1)
            m.Add(U[r][c] >= sum(LBL[r][c]))
    for i in range(len(words)):
        m.Add(sum([X[i]] + [A[(i,r,c)] for r in range(S) for c in range(S-Ls[i]+1)] + [D[(i,r,c)] for r in range(S-Ls[i]+1) for c in range(S)])==1)
    for i,w in enumerate(words):
        cl=clustered_words[w]; L=Ls[i]
        for r in range(S):
            for c in range(S-L+1):
                var=A[(i,r,c)]
                for k in range(L):
                    rr,cc=r, c+k; g=gidx[cl[k]]
                    m.Add(LBL[rr][cc][g]==1).OnlyEnforceIf(var)
                    m.Add(U[rr][cc]==1).OnlyEnforceIf(var)
        for r in range(S-L+1):
            for c in range(S):
                var=D[(i,r,c)]
                for k in range(L):
                    rr,cc=r+k, c; g=gidx[cl[k]]
                    m.Add(LBL[rr][cc][g]==1).OnlyEnforceIf(var)
                    m.Add(U[rr][cc]==1).OnlyEnforceIf(var)
    # non-stacking
    for r in range(S):
        for c in range(S-1):
            for g in range(G):
                for h in range(G):
                    if g!=h: m.AddBoolOr([LBL[r][c][g].Not(), LBL[r][c+1][h].Not()])
    for r in range(S-1):
        for c in range(S):
            for g in range(G):
                for h in range(G):
                    if g!=h: m.AddBoolOr([LBL[r][c][g].Not(), LBL[r+1][c][h].Not()])
    m.Add(sum(X) <= max_excl)
    center=(S-1)/2.0
    m.Minimize(1000000*sum(X) + sum(int((abs(r-center)+abs(c-center))*1000)*U[r][c] for r in range(S) for c in range(S)))
    s=cp_model.CpSolver(); s.parameters.max_time_in_seconds=float(config["solver"]["time_limit_sec"]); s.parameters.num_search_workers=int(config["solver"]["workers"])
    st=s.Solve(m)
    if st not in (cp_model.OPTIMAL, cp_model.FEASIBLE): return None
    placement=[]
    for i,w in enumerate(words):
        placed=False
        L=Ls[i]
        for r in range(S):
            for c in range(S-L+1):
                if s.Value(A[(i,r,c)]):
                    placement.append({"text":w,"row":r,"col":c,"dir":"across","clusters":clustered_words[w]})
                    placed=True; break
            if placed: break
        if placed: continue
        for r in range(S-L+1):
            for c in range(S):
                if s.Value(D[(i,r,c)]):
                    placement.append({"text":w,"row":r,"col":c,"dir":"down","clusters":clustered_words[w]})
                    placed=True; break
            if placed: break
    return placement