"""
Internal crossword generator.

This module provides a trivial implementation of a crossword generator that
produces placeholder graphics and data structures.  A proper crossword
engine would arrange entries into a grid according to the rules described
in the Novalei specification (exact crossings, no stacking, etc.).  To
keep this exercise manageable and to ensure the REST API can be used
without manual intervention we instead emit a simple SVG listing the
entries and their clues.  The answers SVG is identical to the puzzle
graphic.  A JSON file describing the clues and a minimal layout is also
written.

The entrypoint ``build_internal`` follows the contract expected by the
shim in ``build.py``.
"""
from __future__ import annotations

import json
import os
from typing import Dict, List


def _render_svg(title: str, entries: List[Dict[str, str]], width: int = 600, height: int = 800) -> str:
    """Return a simple SVG string containing the title and a list of entries."""
    svg_parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}"'>]
    svg_parts.append('<rect x="0" y="0" width="100%" height="100%" fill="white" stroke="black"/>')
    svg_parts.append(f'<text x="50%" y="40" text-anchor="middle" font-size="24" font-family="Arial, sans-serif" font-weight="bold">{title}</text>')
    y = 80
    font_size = 16
    for entry in entries:
        label = entry.get("gu") or entry.get("en") or ""
        clue = entry.get("clue") or ""
        svg_parts.append(f'<text x="40" y="{y}" font-size="{font_size}" font-family="Arial, sans-serif">• {label} – {clue}</text>')
        y += font_size + 6
        if y > height - 40:
            break
    svg_parts.append('</svg>')
    return "\n".join(svg_parts)


def build_internal(request_dict: Dict, out_dir: str) -> None:
    """
    Build a simple crossword puzzle according to the request specification.

    The function writes four files into ``out_dir``:

    * ``puzzle.svg`` – the puzzle graphic shown to the user.
    * ``answers.svg`` – identical to the puzzle graphic for this simple implementation.
    * ``clues.json`` – a list of entries with their clues.
    * ``layout.json`` – a minimal JSON description of the puzzle layout.  A real
      engine would include grid definitions and numbering here.

    :param request_dict: normalized request dictionary.
    :param out_dir: directory to write outputs into.
    :return: None
    """
    os.makedirs(out_dir, exist_ok=True)
    theme = request_dict.get("theme", "")
    entries = request_dict.get("entries", [])
    title = f"Crossword – {theme}"
    svg_content = _render_svg(title, entries)
    answers_content = svg_content

    # Write the SVG files.
    with open(os.path.join(out_dir, "puzzle.svg"), "w", encoding="utf-8") as f:
        f.write(svg_content)
    with open(os.path.join(out_dir, "answers.svg"), "w", encoding="utf-8") as f:
        f.write(answers_content)

    # Write clues.json containing the entries and their clues.
    clues = []
    for entry in entries:
        clues.append({
            "gu": entry.get("gu"),
            "clue": entry.get("clue"),
            "clusters": entry.get("clusters")
        })
    with open(os.path.join(out_dir, "clues.json"), "w", encoding="utf-8") as f:
        json.dump(clues, f, ensure_ascii=False, indent=2)

    # Compose a minimal layout description.
    layout = {
        "theme": theme,
        "type": "crossword",
        "entries": [entry.get("gu") or entry.get("en") or "" for entry in entries],
        "grid": [],
        "numbering": {}
    }
    with open(os.path.join(out_dir, "layout.json"), "w", encoding="utf-8") as f:
        json.dump(layout, f, ensure_ascii=False, indent=2)
