import json, os, sys, traceback
from typing import Any, Dict

def _load_request(req: Any) -> Dict:
    if isinstance(req, dict):
        return req
    if isinstance(req, str) and os.path.exists(req):
        with open(req, "r", encoding="utf-8") as f:
            return json.load(f)
    raise ValueError("build(): request must be dict or path to JSON")

def _norm_cw(req: Dict) -> Dict:
    out = dict(req)
    out["type"] = "crossword"
    # remove tier if provided
    out.pop("tier", None)
    # defaults
    grid = out.get("grid") or {}
    out["grid"] = {"rows": int(grid.get("rows",17)),
                   "cols": int(grid.get("cols",17)),
                   "symmetry": bool(grid.get("symmetry", False))}
    rules = out.get("rules") or {}
    out["rules"] = {"non_stacking": True,
                    "cluster_crossings_exact": True,
                    "minis_cap": int(rules.get("minis_cap", 2))}
    out["entries_take"] = int(out.get("entries_take", 50))
    # required
    for k in ["theme","entries","cluster_source","rules_version"]:
        if not out.get(k):
            raise ValueError(f"missing required field: {k}")
    # clusters present
    bad = [e for e in out["entries"] if not e.get("clusters")]
    if bad:
        raise ValueError(f"{len(bad)} entry(ies) missing clusters")
    return out

def _save_json(path: str, obj: Dict):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)

def build(request_path_or_dict, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    logp = os.path.join(out_dir, "generator.log")
    try:
        req = _load_request(request_path_or_dict)
        norm = _norm_cw(req)
        _save_json(os.path.join(out_dir, "req_norm.json"), norm)

        # Try to delegate to internal engine
        engine = None
        try:
            import importlib
            for mod, fn in [(".crossword_gen","build_internal"),
                            (".generator","build_crossword"),
                            (".main","build")]:
                try:
                    m = importlib.import_module(mod, package=__package__)
                    f = getattr(m, fn, None)
                    if callable(f):
                        engine = f
                        break
                except Exception:
                    continue
        except Exception:
            pass

        if engine is None:
            with open(logp,"a",encoding="utf-8") as lf:
                lf.write("No internal engine found. Expected one of:\n")
                lf.write(" - crossword_gen.build_internal(request_dict, out_dir)\n")
                lf.write(" - generator.build_crossword(request_dict, out_dir)\n")
                lf.write(" - main.build(request_dict, out_dir)\n")
            return

        # Call engine with normalized dict
        return engine(norm, out_dir)

    except Exception as e:
        with open(logp,"a",encoding="utf-8") as lf:
            lf.write("ERROR: "+str(e)+"\n")
            lf.write(traceback.format_exc())
        raise
