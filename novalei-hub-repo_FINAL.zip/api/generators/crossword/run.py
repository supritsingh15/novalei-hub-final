
#!/usr/bin/env python3
import argparse, sys, yaml, random, unicodedata
from pathlib import Path

def load_config(cfg_path):
    with open(cfg_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def load_words(path):
    ws=[]
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            s=line.strip()
            if not s or s.startswith("#"): continue
            if ":" in s:
                s=s.split(":",1)[0].strip()
            ws.append(unicodedata.normalize("NFC", s))
    return ws

def write_svg(svg_text, out_path):
    Path(out_path).write_text(svg_text, encoding="utf-8")

def main():
    ap=argparse.ArgumentParser(description="Deterministic Gurmukhi Crossword Runner")
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--dataset", required=True)
    ap.add_argument("--mode", choices=["pure","ortools"], default=None)
    ap.add_argument("--out", required=True)
    ap.add_argument("--target", type=int, default=None)
    ap.add_argument("--seed", type=int, default=None)
    args=ap.parse_args()

    cfg = load_config(args.config)
    if args.mode is not None: cfg["MODE"]=args.mode
    if args.target is not None: cfg["TARGET_WORDS"]=args.target
    if args.seed is not None: cfg["SEED"]=args.seed

    words = load_words(args.dataset)
    if len(words) < cfg["TARGET_WORDS"]:
        print(f"Error: dataset has {len(words)} words, need >= {cfg['TARGET_WORDS']}", file=sys.stderr); sys.exit(2)

    random.seed(cfg["SEED"])

    if cfg["MODE"] == "pure":
        from pure_solver import build_puzzle, render_svg
    elif cfg["MODE"] == "ortools":
        try:
            from ortools_solver import build_puzzle, render_svg
        except Exception as e:
            print("OR-Tools mode requested but not available. Install ortools or use --mode pure.", file=sys.stderr)
            raise

    grid, placed = build_puzzle(
        words=words,
        grid_size=cfg["GRID_SIZE"],
        target=cfg["TARGET_WORDS"],
        strict_no_adjacency=cfg["STRICT_NO_ADJACENCY"],
        connector_min=cfg["CONNECTOR_MIN"],
        connector_max=cfg["CONNECTOR_MAX"],
        connector_top_k=cfg["CONNECTOR_TOP_K"],
        stall_limit=cfg["STALL_LIMIT"],
        seed=cfg["SEED"]
    )

    svg = render_svg(
        grid=grid,
        cell=cfg["CELL_SIZE"],
        pad=cfg["RENDER_PAD"],
        stroke_width=cfg["BOX_STROKE_WIDTH"],
        bold_numbers=cfg["BOLD_NUMBERS"]
    )
    write_svg(svg, args.out)
    print(f"Wrote {args.out} with {len(placed)} placed words.")

if __name__ == "__main__":
    main()
