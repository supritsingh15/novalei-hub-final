"""Crossword generator package."""

from .build import build  # expose build at package level
