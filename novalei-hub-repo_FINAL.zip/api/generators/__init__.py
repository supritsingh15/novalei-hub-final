"""Puzzle generators package.

This namespace contains subpackages for each type of puzzle engine (search,
crossword, sudoku, etc.).  Each subpackage provides a shim ``build``
function and an internal ``*_gen`` module with the actual implementation.
"""
