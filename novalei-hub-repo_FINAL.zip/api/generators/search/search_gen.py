"""
Internal word search generator.

This module implements a very simple word search puzzle generator suitable
for demonstration and testing purposes.  The real Novalei engine uses
advanced algorithms to arrange words on a grid with minimal overlap and
proper handling of grapheme clusters.  Here we take a much simpler
approach: we do not attempt to place words on a grid.  Instead we
generate a placeholder SVG containing the list of words and some
decorative elements.  The answers SVG is identical for simplicity.

The ``build_internal`` function follows the contract expected by the
provided shim in ``build.py``.  It accepts a normalized request
dictionary and an output directory.  It writes ``puzzle.svg``,
``answers.svg`` and ``layout.json`` into that directory.
"""
from __future__ import annotations

import json
import os
import random
from typing import Dict, List


def _render_svg(title: str, words: List[Dict[str, str]], width: int = 600, height: int = 800) -> str:
    """Return a simple SVG string containing the title and a list of words."""
    # Start with a white background.
    svg_parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}"'>
    ]
    svg_parts.append('<rect x="0" y="0" width="100%" height="100%" fill="white" stroke="black"/>')
    svg_parts.append(f'<text x="50%" y="40" text-anchor="middle" font-size="24" font-family="Arial, sans-serif" font-weight="bold">{title}</text>')
    # List the words starting below the title.
    y = 80
    font_size = 16
    for word in words:
        label = word.get("gu") or word.get("en") or ""
        svg_parts.append(f'<text x="40" y="{y}" font-size="{font_size}" font-family="Arial, sans-serif">• {label}</text>')
        y += font_size + 6
        if y > height - 40:
            break
    svg_parts.append('</svg>')
    return "\n".join(svg_parts)


def build_internal(request_dict: Dict, out_dir: str) -> None:
    """
    Build a simple word search puzzle according to the request specification.

    The function writes three files into ``out_dir``:

    * ``puzzle.svg`` – the puzzle graphic shown to the user.
    * ``answers.svg`` – the same graphic for the answers section.
    * ``layout.json`` – a minimal JSON description of the puzzle layout.  This
      file contains the theme, list of word labels and a placeholder grid
      definition.  More sophisticated engines would populate this with
      coordinates for each letter and word placement.

    :param request_dict: normalized request dictionary.
    :param out_dir: directory to write outputs into.
    :return: None
    """
    os.makedirs(out_dir, exist_ok=True)
    theme = request_dict.get("theme", "")
    words = request_dict.get("words", [])
    title = f"Word Search – {theme}"
    svg_content = _render_svg(title, words)
    answers_content = svg_content  # For this simple implementation, answers are identical.

    # Write SVG files.
    with open(os.path.join(out_dir, "puzzle.svg"), "w", encoding="utf-8") as f:
        f.write(svg_content)
    with open(os.path.join(out_dir, "answers.svg"), "w", encoding="utf-8") as f:
        f.write(answers_content)

    # Compose a minimal layout description.
    layout = {
        "theme": theme,
        "type": "wordsearch",
        "words": [word.get("gu") or word.get("en") or "" for word in words],
        "grid": [],
        "placements": []
    }
    with open(os.path.join(out_dir, "layout.json"), "w", encoding="utf-8") as f:
        json.dump(layout, f, ensure_ascii=False, indent=2)
